import React, {useState} from 'react'

function MyTextBox(){
    const [name, setName] = useState('')
    function handleChange(event){
        setName(event.target.value);
    }

    return (<div className="">
        <h1>My Name is: {name}</h1>
        <input type="text" value={name} onChange={handleChange}></input>
    </div>
    )
}

export default MyTextBox;