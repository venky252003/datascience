// const proxy = require('http-proxy-middleware')

// module.exports = function (app) {
//   app.use(proxy('/api', {
//     target: 'http://localhost:3000',
//     pathRewrite: { '^/api' : '' }
//   }))
// }

//const { createProxyMiddleware } = require('http-proxy-middleware');

// module.exports = function(app) {
//     app.use(createProxyMiddleware("/api", { target: "http://localhost:4000" }));
// };

const { createProxyMiddleware } = require('http-proxy-middleware');
module.exports = function(app) {
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'http://localhost:4000',
      pathRewrite: { '^/api' : '' },
      changeOrigin: true,
    })
  );
};